# ShipKit

ShipKit is a polished SaaS starter built with Next.js App Router, Supabase, Stripe, Tailwind CSS, and Resend.

It gives developers a clean starting point for shipping a real product: authentication, billing, dashboard UI, internationalized copy, dark mode, and starter-kit delivery are already wired in.

## Features

- Next.js App Router architecture with server-first patterns
- Supabase authentication with signup, login, logout, and session handling
- Protected dashboard routes with a reusable workspace layout
- Typed UI primitives: `Button`, `Input`, `Card`, `Modal`
- Stripe checkout, billing portal, and webhook sync
- Supabase-backed `public.users` table for application user data
- English/French language toggle
- Dark mode with persisted preference
- Starter kit download surface in the dashboard
- Transactional email hooks with Resend

## Tech Stack

- Next.js 16
- React 19
- TypeScript
- Tailwind CSS 4
- Supabase
- Stripe
- Resend
- Zod

## Quick Start

### 1. Install dependencies

```bash
npm install
```

### 2. Create your environment file

```bash
cp .env.example .env.local
```

Fill in the placeholders in `.env.local`.

At minimum for local auth you should set:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

For the full starter, also set:

```env
SUPABASE_SERVICE_ROLE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_PRICE_STARTER=
STRIPE_PRICE_PRO=
RESEND_API_KEY=
EMAIL_FROM=ShipKit <hello@yourdomain.com>
STARTER_KIT_DOWNLOAD_URL=
```

### 3. Apply Supabase migrations

Run the SQL files in `supabase/migrations/` against your Supabase project:

- `20260323173000_create_users_table.sql`
- `20260323180000_add_stripe_billing_fields.sql`
- `20260323183000_add_subscription_plan.sql`

### 4. Start the app

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Available Scripts

```bash
npm run dev
npm run build
npm run start
npm run typecheck
npm run grant:pro -- --email you@example.com
```

## Project Structure

```text
app/
  (app)/            Protected workspace routes
  (auth)/           Auth screens and server actions
  api/              Server routes for billing and starter-kit delivery
components/
  auth/             Auth-related UI
  billing/          Pricing and billing UI
  brand/            Logo and brand primitives
  layout/           Shared layout system
  ui/               Reusable UI primitives
lib/
  i18n.ts           Shared copy and locale helpers
  stripe/           Stripe helpers and billing sync
  supabase/         Browser, server, and admin Supabase clients
  users.ts          App user model and sync helpers
scripts/
  grant-pro-access.mjs
supabase/
  migrations/       SQL schema and billing migrations
public/
  starter-kit.zip   Downloadable starter-kit asset
```

## Notes

- `.env.local`, `.next`, and `node_modules` are intentionally not included in the starter kit
- `NEXT_PUBLIC_*` variables are exposed to the browser and should only contain safe public values
- `SUPABASE_SERVICE_ROLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, and `RESEND_API_KEY` must stay server-only
- Replace `public/starter-kit.zip` with your real archive before distribution if needed
