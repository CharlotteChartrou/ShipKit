import { NextResponse } from "next/server";
import { getStarterKitEnv } from "@/lib/env";
import { getCurrentAppUser } from "@/lib/users";

export async function GET(request: Request) {
  const appUser = await getCurrentAppUser();

  if (!appUser) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("next", "/dashboard");
    return NextResponse.redirect(loginUrl, { status: 303 });
  }

  if (appUser.subscription_status !== "active") {
    return NextResponse.redirect(new URL("/billing", request.url), { status: 303 });
  }

  const { starterKitDownloadUrl } = getStarterKitEnv();

  if (starterKitDownloadUrl) {
    return NextResponse.redirect(starterKitDownloadUrl, { status: 303 });
  }

  const body = [
    "ShipKit starter kit delivery",
    "",
    "Your starter kit access is active.",
    "Set STARTER_KIT_DOWNLOAD_URL in your environment to point this button at your real ZIP delivery.",
    "",
    "Suggested env var:",
    "STARTER_KIT_DOWNLOAD_URL=https://example.com/shipkit-starter-kit.zip",
  ].join("\n");

  return new NextResponse(body, {
    headers: {
      "Content-Disposition": 'attachment; filename=\"shipkit-starter-kit.txt\"',
      "Content-Type": "text/plain; charset=utf-8",
    },
  });
}
